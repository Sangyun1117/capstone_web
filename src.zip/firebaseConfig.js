// Import the functions you need from the SDKs you need
import { initializeApp } from 'firebase/app';
import { getDatabase } from 'firebase/database';
import { getFirestore } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: 'AIzaSyCfK64E-XJLQAd1MsczhbXGS_gNzXgQdXA',
  authDomain: 'capstone-ac206.firebaseapp.com',
  databaseURL: 'https://capstone-ac206-default-rtdb.firebaseio.com',
  projectId: 'capstone-ac206',
  storageBucket: 'capstone-ac206.appspot.com',
  messagingSenderId: '1005177753804',
  appId: '1:1005177753804:web:e1e7e0cab7582236c1f269',
  measurementId: 'G-TE1WQE0D45',
};

const app = initializeApp(firebaseConfig);
const database = getDatabase(app);
const auth = getAuth(app);
const firestore = getFirestore(app);
export { database, auth, firestore };
