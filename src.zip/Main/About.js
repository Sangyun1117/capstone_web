const About = () => (
  <div>
    <h1>About</h1>
    <p>About, indroducing page.</p>
  </div>
);
export default About;
